<template>
    <div>
      <!-- FOOTER -->
      <footer class="footer">
        <div class="container">
          <p class="mb-1">&copy; 2018 Troubleshooting Vue.js</p>
        </div>
      </footer>
    </div>
    <!-- FOOTER -->  
</template>

<script>

    export default {
        name: "Footer"
    };

</script>

<style>
</style>