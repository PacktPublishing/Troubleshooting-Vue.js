import Vue from 'vue'
import { mount } from '@vue/test-utils'
import HelloWorld from '@/components/HelloWorld'

describe('HelloWorld.vue', () => {

  //Test 1 - setup correct
  test ("Setup correct", ()=>{
    expect(true).toBe(true);
  })

})
